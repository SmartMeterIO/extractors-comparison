var chartsData = {
  "average": {
    "legend": [
      "TOTAL",
      "jp@gc - Dummy Sampler"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 0.0
        }
      ],
      [
        {
          "run": 1,
          "value": 0.0
        }
      ]
    ]
  },
  "median": {
    "legend": [
      "TOTAL",
      "jp@gc - Dummy Sampler"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 0.0
        }
      ],
      [
        {
          "run": 1,
          "value": 0.0
        }
      ]
    ]
  },
  "errorRate": {
    "legend": [
      "TOTAL",
      "jp@gc - Dummy Sampler"
    ],
    "data": [
      [
        {
          "run": 1,
          "value": 0.0
        }
      ],
      [
        {
          "run": 1,
          "value": 0.0
        }
      ]
    ]
  }
}